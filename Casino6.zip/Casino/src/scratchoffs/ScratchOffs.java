/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scratchoffs;

import casino.Player;
import constants.Constants;
import java.util.Scanner;

/**
 *
 * @author Karin Whiting UCF COP 3330
 */
public class ScratchOffs
{
    private final Player player;
    private boolean play;
    private final Scanner scan;    
    private OneDollar one;
    private FiveDollar five;
    private TenDollar ten;
    private int input;

    public ScratchOffs(Player player)
    {
        this.player = player;
        this.play = true;
        scan = new Scanner(System.in);
    }

    public void play()
    {
        int type;
        int quantity;
        int balance;
        String cont;
        
        displayRules();

        if(player.getCash() < Constants.OneDollar)
        {
            System.out.println("Player does not have enough cash to play");
            play = false;
        }
        
        while(play)
        {
            System.out.println("Which type of scratch off ticket would you like? (1 = One Dollar, 5 = Five Dollar, 10 = Ten Dollar");
            type = scan.nextInt();
            
            System.out.println("How many scratch off tickes do you want?");
            quantity = scan.nextInt(); 
            
            balance =  this.player.getCash() - (type * quantity);
            
            System.out.println("Funds remaining after scratchoff purchase: " + balance);
            
            if(balance < Constants.OneDollar)
            {
                System.out.println("Player does not have enough cash to play Scratchoff.");
                play = false;
                break;
            }
            
            for(int i=0; i<quantity; i++)
            {
                switch(type)
                {
                    case Constants.OneDollar:
                         this.player.setCash(this.player.getCash()-Constants.OneDollar);
                         this.one = new OneDollar(this.player); 
                         break;
                    case Constants.FiveDollar:
                         this.player.setCash(this.player.getCash()-Constants.FiveDollar);
                         this.five = new FiveDollar(this.player);
                         break;
                    case Constants.TenDollar:
                         this.player.setCash(this.player.getCash()-Constants.TenDollar);
                         this.ten = new TenDollar(this.player);                         
                         break;
                }
            }
            
            System.out.println("Current funds: " + player.getCash());
             
            if(balance < Constants.OneDollar)
            {
                System.out.println("Player does not have enough cash to continue to play Scratchoff.");
                play = false;
                break;
            }
            else
            {
                System.out.println("Would you like to play again (y/n)?");
                cont = scan.next();
            }
            
            play = "Y".equals(cont) || "y".equals(cont);                 
        }                

        System.out.println("Cash balance: " + player.getCash());
    }
    
    public void displayRules()
    {      
        System.out.println("Lets Play Scratch Off Tickets!");
        System.out.println("Players can select fron One Dollar, Five Dollar and Ten Dollar Tickets");
        System.out.println("Prizes are based on the ticket selected");  
        System.out.println(" "); 
    }
}
