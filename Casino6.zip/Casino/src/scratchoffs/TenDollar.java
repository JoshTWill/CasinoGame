package scratchoffs;

import casino.Player;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

public class TenDollar {

    private final Player player;
    private char winningBonus;
    private int winningNumber;
    private ArrayList<Integer> playerNumbers;
    private ArrayList<Double> prizes;
    private ArrayList<Character> bonus;
    private final Random rand;
    private final DecimalFormat df = new DecimalFormat("#.00");
 
    private final char[] SYMBOLS = {'$', '%', '&', '#', '@', '!'};
    private final int BASE = 60;
    private final int NUMS = 15;
    private final int SYMS = 4;
    private final double BONUS = 30.00;
    private final int CARDWIDTH = 45;   
    
    public TenDollar(Player player) {
        this.player = player;
        rand = new Random();
        createTicket();
        displayTicket();
        cashTicket();
    }

    private void displayTicket() {
        String headerFooter = "+-------------------------------------------+";
        String output = "";
        
        System.out.println(headerFooter); 
        
        String winNum = "| WINNING NUMBER         " + this.winningNumber;
        System.out.print(winNum);
        printPadding(winNum.length() + 1);
        System.out.println("|");
        
        System.out.print("|");
        printPadding(2);
        System.out.println("|");         
        
        System.out.print("| YOUR NUMBERS "); 
        printPadding(16);
        System.out.println("|");        
                
        for(int i = 0; i< this.playerNumbers.size(); i++)
        {             
             if(i>0 && i%5==0)
             {
                System.out.print("|     "); // 6
                System.out.print(output);
                printPadding(7 + output.length());
                System.out.println("|");
                output = "";
             }
            
             output += "  " + this.playerNumbers.get(i);             
        }  
        
        // Check to make sure outpt is empty. if not, there are unprinted numbers
        if(!"".equals(output))
        {
            System.out.print("|     "); // 6
            System.out.print(output);
            printPadding(7 + output.length());
            System.out.println("|");
        }
        
        System.out.print("|");
        printPadding(2);
        System.out.println("|"); 
        
        System.out.print("| PRIZES  ");  
        printPadding(11);
        System.out.println("|");     
        
        output = "";        
        for(int i = 0; i< this.prizes.size(); i++)
        {             
            if(i>0 && i%5==0)
            {
               System.out.print("| ");
               System.out.print(output);
               printPadding(3 + output.length());
               System.out.println("|");
               output = "";
             }
            
            output += "  $" + df.format(this.prizes.get(i));             
        }  
        
        // Check to make sure outpt is empty. if not, there are unprinted numbers
        if(!"".equals(output))
        {
            System.out.print("| ");
            System.out.print(output);
            printPadding(3 + output.length());
            System.out.println("|");
        }
        
        System.out.print("|");
        printPadding(2);
        System.out.println("|");        
        
        System.out.print("| SYMBOLS ");  
        printPadding(11);
        System.out.println("|");
        
        output = ""; // reset our string
        System.out.print("|     "); // 6       
        for(int i= 0; i< this.bonus.size(); i++)
        {
            output += "    " + this.bonus.get(i);             
        }  
        System.out.print(output);
        printPadding(7 + output.length());
        System.out.println("|");          
        
        System.out.println(headerFooter);  
    }

    private void createTicket() {
        this.playerNumbers = new ArrayList<>();
        this.prizes = new ArrayList<>();
        this.bonus = new ArrayList<>();

        this.winningNumber = randomNumber();
        this.winningBonus = randomSymbol();

        for (int i = 0; i < NUMS; i++) {
            this.playerNumbers.add(randomNumber());
            this.prizes.add(randomPrize());
        }

        for (int i = 0; i < SYMS; i++) {
            this.bonus.add(randomSymbol());
        }
    }

    private void cashTicket() {
        double cash = 0.00;

        for (int i = 0; i < NUMS; i++) {
            int pNum = this.playerNumbers.get(i);
            if (pNum == this.winningNumber) {
                double prize = this.prizes.get(i);
                cash += prize;
            }
        }

        for (int i = 0; i < SYMS; i++) {
            char pBonus = this.bonus.get(i);
            if (pBonus == this.winningBonus) {
                cash += BONUS;
            }
        }

        System.out.println("Bonus Symbol is: " + this.winningBonus);
        System.out.println("Bonus is worth: $" + df.format(this.BONUS));
        System.out.println("Your ten dollar scratch off won you: $" + df.format(cash));

        cash += this.player.getCash();        
        this.player.setCash((int)cash);
        int pCash = this.player.getCash();
    }

    private int randomNumber() {
        int randValue;
        randValue = rand.nextInt(BASE) + 1;
        return randValue;
    }

    private char randomSymbol() {
        char symbol;
        int num;
        num = rand.nextInt(SYMBOLS.length);
        symbol = SYMBOLS[num];
        return symbol;
    }

    private double randomPrize() {
        double randNum;
        randNum = (double) (rand.nextInt(BASE) + 1);
        return randNum;
    }

    private void printPadding(int lineLength) {
        for(int i=0; i< CARDWIDTH - lineLength; i++)
        {
            System.out.print(" ");
        }
    }
}
