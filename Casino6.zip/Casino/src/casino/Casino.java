/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;

import blackjack.BlackJack;
import constants.Constants;
import java.util.Scanner;
import scratchoffs.ScratchOffs;
import slots.Slots;
import userInterface.CasinoUi;
/**
 *
 * @author Karin Whiting UCF COP 3330
 */
public class Casino
{
    // member variables
    private static BlackJack blackJack;
    private static ScratchOffs scratchers;
    private static Slots slots;
    private static Player player;
    private static Scanner scan;
    private static CasinoUi ui;   
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        //int game = 0;  
        
        // instantiate the scanner object
        //scan = new Scanner(System.in);

        // instantiate the player object
        player = new Player();
        ui = new CasinoUi(new Casino());
         
        // display the game menu
        //game = displayMenu();

        /*while(game != 0)
        {
            switch(game)
            {
                case Constants.BLACK_JACK:
                    blackJack = new BlackJack(player);
                    blackJack.play();
                    break;
                case Constants.SCRATCH:
                    scratchers = new ScratchOffs(player);
                    scratchers.play();
                    break;
                case Constants.SLOTS:
                    slots = new Slots(player);  
                    slots.play();
                    break;
                default:
                    System.out.println("Invalid game selection, try again");
            }
             
             //game = displayMenu();
        }*/
    }

    private static int displayMenu()
    {
        System.out.println("Welcome to Knights Casino!");
        System.out.println("");
        
        int select = 0;
        
        do
        {
            System.out.println("Select the game to play");
            System.out.println("0. Quit");
            System.out.println("1. Black Jack");
            System.out.println("2. Scratch Off Tickets");
            System.out.println("3. Slot Machines");
            System.out.println("");
            System.out.println("Enter the number of your choice: ");
            select = scan.nextInt();
        
        } while(select < 0 || select > Constants.SLOTS ); // Anything less than 3
        
        return select;
    }  
    
  // Getter
  public BlackJack getblackJack() {
    return Casino.blackJack;
  }

  // Setter
  public void setblackJack(BlackJack newBlackJack) {
    Casino.blackJack = newBlackJack;
  }    
  
  // Getter
  public ScratchOffs getScratchOffs() {
    return Casino.scratchers;
  }

  // Setter
  public void setScratchOffs(ScratchOffs newScratchOffs) {
    Casino.scratchers = newScratchOffs;
  }
  
  // Getter
  public Slots getSlots() {
    return Casino.slots;
  }

  // Setter
  public void setSlots(Slots newSlots) {
    Casino.slots = newSlots;
  }
    
  // Getter
  public Player getPlayer() {
    return Casino.player;
  }

  // Setter
  public void setPlayer(Player newPlayer) {
    Casino.player = newPlayer;
  }    
}
