package userInterface;

import casino.Player;
import constants.Constants;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.GridLayout;
import java.awt.event.*;
import java.awt.Image;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.IOException;

public class SlotsUi extends JPanel
{
    static final File DIR = new File("src/images/slots/");
    
    //Member variables 
    CasinoUi casinoUi;
    Player player;
    JLabel data;
    JLabel bet;
    JButton spin;
    JPanel headerPanel;
    JPanel slotsPanel;
    Random rand;
    ArrayList<ImageIcon> images;
    ArrayList<Integer> spinNums;
    
    public SlotsUi(Player player, CasinoUi casinoUi)
    {
        this.player = player;
        this.casinoUi = casinoUi;
        this.rand = new Random();
        
        initImages();
        initComponents();
    }

    // Getter for player
    public Player getPlayer()
    {
        return this.player;
    }
    
    // Getter for random
    public Random getRandom()
    {
        return this.rand;
    }
    
    public JPanel getSlotsPanel()
    {
        return this.slotsPanel;
    }
    
    // Getter for CasinoUi
    public CasinoUi getCasinoUi()
    {
        return this.casinoUi;
    }
    
     public ArrayList<ImageIcon> getImages()
     {
         return this.images;
     }
    
    private void initComponents() 
    {
        this.data = new JLabel("Welcome to Knights Casino Slots!!");
        this.bet = new JLabel("The Bet is $" + Constants.BET);
        
        this.spin = new JButton("Spin");
        this.spin.addActionListener(new SpinListener());        
        
        // Create header panel
        this.headerPanel = new JPanel();
        this.headerPanel.setLayout(new GridLayout(3,1));
        this.headerPanel.add(this.data);
        this.headerPanel.add(this.bet);
        this.headerPanel.add(this.spin); 
        
        // Create slots panel with titled border
        this.slotsPanel = new JPanel();
        this.slotsPanel.setLayout(new GridLayout(1,3));
        
        TitledBorder title;
        title = BorderFactory.createTitledBorder("Your spin");
        this.slotsPanel.setBorder(title);
        
        // Set main JPanel layout
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.add(this.headerPanel);
        this.add(this.slotsPanel);
    }
    
    private void initImages()
    {
        this.images = new ArrayList();
        if (DIR.isDirectory()) { 
            // make sure it's a directory
            for (final File f : DIR.listFiles()) 
            {                
                try 
                {
                    URL imgUrl =  f.getCanonicalFile().toURI().toURL();
                    this.images.add(createImageIcon(imgUrl, f.getName()));
                }
                catch (MalformedURLException e) {}
                catch (IOException e) {}
            }
         }        
    }   
    
    private ImageIcon createImageIcon(URL imgUrl, String imageDescription)
    {
        ImageIcon imageIcon;        
        if(imgUrl != null)
        {
            imageIcon = new ImageIcon(imgUrl, imageDescription);
            imageIcon = imageResize(imageIcon);
            return imageIcon;
        }
        else
        {
            System.out.print("Unable to find file " + imageDescription);
            return null;
        }
    }
    
    private ImageIcon imageResize(ImageIcon imageIcon)
    {
        Image image = imageIcon.getImage();
        Image newImage = image.getScaledInstance(100, 75, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newImage);
        return imageIcon;
    }
    
    private class SpinListener implements ActionListener {
        JLabel reel1;
        JLabel reel2;
        JLabel reel3;
        
        public SpinListener() {
        }

        @Override
        public void actionPerformed(ActionEvent ae) {
            spin();
            results();
        }
        
        private void spin()
        {
            int num; 
            int imageSize = getImages().size();
            int playerCash = getPlayer().getCash() - Constants.BET;
            getPlayer().setCash(playerCash);           
            getCasinoUi().updatePlayerUi();
            
            spinNums = new ArrayList();
            
            // Clear the panel before spinning
            getSlotsPanel().removeAll();            
           
            num = getRandom().nextInt(imageSize);
            spinNums.add(num);
            reel1 = createReel(num);
            
            num = getRandom().nextInt(imageSize);
            spinNums.add(num);
            reel2 = createReel(num);
            
            num = getRandom().nextInt(imageSize);
            spinNums.add(num);
            reel3 = createReel(num);           
                        
            getSlotsPanel().add(reel1);
            getSlotsPanel().add(reel2);
            getSlotsPanel().add(reel3);

            getSlotsPanel().revalidate();
            getSlotsPanel().repaint();            
        }
        
        // Method to create the jLabel. Prevent duplicate code
        private JLabel createReel(int num)
        {
            JLabel reel = new JLabel();           
            ImageIcon icon = getImages().get(num);  
            reel.setIcon(icon);
            return reel;
        }        
        
        private void results()
        {
            ArrayList list = spinNums;        
            if(list.get(0) == list.get(1) && list.get(1) == list.get(2))
            {
                JOptionPane.showMessageDialog(null, "Three symbols matched, you won $50!!" );
                int cash = getPlayer().getCash() + 50;
                getPlayer().setCash(cash);
            }
            else if(list.get(0) == list.get(1) || list.get(1) == list.get(2) || list.get(0) == list.get(2))
            {
                JOptionPane.showMessageDialog(null, "Three symbols matched, you won $5!" );
                int cash = getPlayer().getCash() + 5;
                getPlayer().setCash(cash);
            }
            else 
            {
                JOptionPane.showMessageDialog(null, "Sorry, no symbols matched." );
            }
            
            // Update the playerUi in CasinoUi
            getCasinoUi().updatePlayerUi();
        }
    }
}
