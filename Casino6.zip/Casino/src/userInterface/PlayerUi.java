
package userInterface;

import casino.Player;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PlayerUi extends JPanel
{
    Player player;
    JLabel cashLabel;
    JLabel cashBalance;    
    
    public PlayerUi(Player player)
    {
        this.player = player;
        initComponents();
    }

    private void initComponents() 
    {
        // Set player name and cash amount
        String playerName = JOptionPane.showInputDialog(null, "Enter Name of Player");
         this.player.setName(playerName);                    
        
         // Require a non-empty string to be entered
        String cashAmount = JOptionPane.showInputDialog(null, "Enter cash to Play");
        int cash = Integer.parseInt(cashAmount);
        this.player.setCash(cash);       
        
        // Set panel size and border
        this.setPreferredSize(new Dimension(150, 800));
        TitledBorder title = BorderFactory.createTitledBorder(playerName);
        this.setBorder(title);        
        
        // Set label for cash balance
        this.cashLabel = new JLabel("Cash Balance: $"); 
        this.cashBalance = new JLabel(Integer.toString(this.player.getCash()));
        
        // Add labels to the playerUi panel
        this.add(this.cashLabel);
        this.add(this.cashBalance);
    }
    
    public static boolean isNumeric(String str) { 
        try {  
          Double.parseDouble(str);  
          return true;
        } catch(NumberFormatException e){  
          return false;  
        }  
    }
        
     // Setter
  public void setPlayer(Player newPlayer) {
    this.player = newPlayer;
  }    
  
  // Getter
  public Player getPlayer() {
    return this.player;
  }
  
   // Setter
  public void setCashLabel(JLabel newcashLabel) {
    this.cashLabel = newcashLabel;
  }    
  
  // Getter
  public JLabel getCashLabel() {
    return this.cashLabel;
  }
  
   // Setter
  public void setcashBalance(JLabel newBlackJack) {
    this.cashBalance = newBlackJack;
  }    
  
  // Getter
  public JLabel getcashBalance() {
    return this.cashBalance;
  } 
}
