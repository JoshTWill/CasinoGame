/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import casino.Casino;
import casino.Player;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;


public class CasinoUi implements ActionListener 
{
    //Member Variables for CasinoUi    
    JFrame frame; 
    Casino casino;
    PlayerUi playerUi;
    BlackJackUi blackJackUi;
    SlotsUi slotsUi;
    ScratchOffsUi scratchOffsUi;
    JPanel casinoPanel;
    JPanel buttonPanel;
    JPanel gamePanel;
    JPanel blackJackPanel;
    JPanel scratchOffPanel;
    JPanel slotsPanel;
    JButton slots;
    JButton blackJack;
    JButton scratchers;
    private static final String SLOTS = "Slots";
    private static final String BLACK_JACK = "Black Jack";
    private static final String SCRATCH_OFFS = "Scratch Offs";
    CardLayout cardLayout;    
    
    public CasinoUi(Casino casino) 
    {
        this.casino = casino;
        initObjects();
        initComponents();        
    }
    
    public void updatePlayerUi()
    {
        Player p = this.playerUi.getPlayer();
        this.playerUi.cashBalance.setText(Integer.toString(p.getCash()));
    }
    
    private void initObjects() 
    {        
        playerUi = new PlayerUi(this.casino.getPlayer());
        blackJackUi = new BlackJackUi(this.casino.getPlayer(), this);
        slotsUi = new SlotsUi(this.casino.getPlayer(), this);
        scratchOffsUi = new ScratchOffsUi(this.casino.getPlayer(), this);
        cardLayout = new CardLayout();
    }
        
    private void initComponents() 
    {
        frame = new JFrame("Knights Casino");        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 800);
        
        // Create a panel to hold the buttons
        buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(800, 50));
        
        // Create the buttons
        blackJack = new JButton(BLACK_JACK);
        blackJack.addActionListener(this); 
        slots = new JButton(SLOTS);
        slots.addActionListener(this);
        scratchers = new JButton(SCRATCH_OFFS);
        scratchers.addActionListener(this);
       
        buttonPanel.add(blackJack);
        buttonPanel.add(slots);
        buttonPanel.add(scratchers);        
        
        cardLayout = new CardLayout();
        gamePanel = new JPanel(cardLayout);
        gamePanel.setPreferredSize(new Dimension(600, 800));
        
        TitledBorder title = BorderFactory.createTitledBorder("Games");
        this.gamePanel.setBorder(title);        
        
        this.gamePanel.add(this.blackJackUi, BLACK_JACK); 
        this.gamePanel.add(this.slotsUi, SLOTS);
        this.gamePanel.add(this.scratchOffsUi, SCRATCH_OFFS);
        
       frame.getContentPane().add(buttonPanel, BorderLayout.NORTH);
       frame.getContentPane().add(playerUi, BorderLayout.WEST);
       frame.getContentPane().add(gamePanel, BorderLayout.CENTER);
       frame.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
       this.cardLayout.show(this.gamePanel, ae.getActionCommand() );
       this.frame.revalidate();
       this.frame.repaint();
    }
}
