package userInterface;

import casino.Player;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ScratchOffsUi extends JPanel
{
    //Member Variables
    CasinoUi casinoUi;
    Player player;
    JLabel data;
      
    public ScratchOffsUi(Player player, CasinoUi casinoUi)
    {
        this.player = player;
        this.casinoUi = casinoUi;
        initComponents();
    }

    private void initComponents() 
    {
        this.data = new JLabel("Welcome to Knights Casino Scratch Offs!!");
        this.add(this.data);
    }
}
