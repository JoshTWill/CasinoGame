
package userInterface;

import casino.Player;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BlackJackUi extends JPanel 
{
    CasinoUi casinoUi;
    Player player; 
    JLabel data;
    
    public BlackJackUi(Player player, CasinoUi casinoUi)
    {
      this.player = player;
      this.casinoUi =  casinoUi;      
      initComponents();
    }    
    
    private void initComponents()
    {
        this.data = new JLabel("Welcome to Knights Casino Black Jack!!");
        
        // Add data label to the blackjack UI panel
        this.add(this.data);
    }
}